# Watson AI

Prompt-driven image → animated-video generator with 3D-like motion animations.

## Features

- Single & bulk image upload
- Smooth, premium-quality short videos from images using your text prompt
- Animated 3D motion (AnimateDiff via Replicate, or HuggingFace OSS)
- User library: save video metadata, download MP4/WebM
- Firebase Auth (email/password)
- Async job queue, progress tracker, and strong error handling
- Luxury UI: day/night mode, gold accents, 3D transitions
- Static blog, terms, privacy, about pages

---

## Tech Stack

- **Frontend:** React, Tailwind CSS, Framer Motion
- **Backend:** Node.js (Vercel Functions compatible)
- **Auth/DB/Storage:** Firebase
- **AI Models:** Replicate AnimateDiff (API), HuggingFace (OSS)
- **CI/CD:** Dyad.sh → GitHub → Vercel/Netlify

---

## Getting Started

### 1. Clone & Install

```bash
git clone https://github.com/Adnan-Hack/watson-ai.git
cd watson-ai
npm install
```

### 2. Set Up Environment Variables

Create `.env.local` using the provided template:

```env
# Replicate
REPLICATE_API_KEY=your_replicate_key

# Firebase
FIREBASE_API_KEY=your_firebase_key
FIREBASE_AUTH_DOMAIN=your_auth_domain
FIREBASE_PROJECT_ID=your_project_id
FIREBASE_STORAGE_BUCKET=your_storage_bucket
FIREBASE_MESSAGING_SENDER_ID=your_sender_id
FIREBASE_APP_ID=your_app_id
```

> _You **must** use Vercel/Netlify environment variables for production!_

### 3. Local Development

```bash
npm run dev
```

### 4. Deploy

- **Netlify:** Deploy via [app.netlify.com](https://app.netlify.com/)
- **Vercel:** Deploy via [vercel.com](https://vercel.com/)

---

## Demo Account

A public demo account is available (see `src/demo/README.md`). Admin page allows clearing demo jobs.

---

## Admin Checklist

- [ ] Register/login user
- [ ] Upload 1 image → animate (3s) → download MP4
- [ ] Upload 3 images → animate (5s) → check library
- [ ] Saved library + downloads work
- [ ] Blog, Terms, Privacy pages accessible

---

## API/Model Integration

- **Replicate AnimateDiff** via `/api/animate`
- **Duration mapping:** `3s=90`, `5s=150`, `8s=240`, `10s=300` frames

---

## License

MIT (see LICENSE)