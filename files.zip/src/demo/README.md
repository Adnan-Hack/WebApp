# Demo Account

- Log in with the email: `demo@watson.ai` and password: `demo123`
- Try generating up to 5-10 sample videos.
- Admin page (`/admin`) lets you clear demo jobs.

This demo account is reset periodically and videos may be cleared at any time.