import Layout from "@/components/Layout";
import Link from "next/link";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <Layout>
      <section className="max-w-3xl mx-auto py-16 px-4 text-center">
        <motion.h1
          className="font-luxury text-4xl sm:text-5xl mb-4 text-gold-neon"
          initial={{ y: -40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          Create Animated Videos from Images in Seconds
        </motion.h1>
        <motion.p
          className="text-xl text-gray-700 dark:text-gold mb-8"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1, delay: 0.2 }}
        >
          Upload images, enter a prompt, and get cinematic motion videos with <span className="text-gold">premium 3D animation</span>.
        </motion.p>
        <Link
          href="/app"
          className="inline-block px-8 py-3 rounded bg-gold-neon text-black font-semibold shadow-lg hover:scale-105 transition"
        >
          Try Watson AI
        </Link>
        <div className="mt-12">
          <h2 className="font-luxury text-2xl mb-4">Latest from our Blog</h2>
          <div className="flex flex-col items-center gap-2">
            <Link href="/blog/ai-creative-video" className="hover:underline text-gold">How AI is Revolutionizing Creative Video</Link>
            <Link href="/blog/animatediff-open-source" className="hover:underline text-gold">AnimateDiff & Open Source: Unleashing 3D Motion</Link>
            <Link href="/blog/premium-ai-effects" className="hover:underline text-gold">Premium Effects with Free AI Tools</Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}