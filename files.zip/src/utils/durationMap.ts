export const durationFrames = {
  "3s": 90,
  "5s": 150,
  "8s": 240,
  "10s": 300
};